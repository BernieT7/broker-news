# Source Quality Rules

## Source hierarchy

### Tier 0 — Formal primary legal/rule material
Highest authority for exact rules, effective dates, and applicability.

Examples:
- statute / act;
- enforcement decree;
- formal regulatory rule;
- KRX market/listing/business rule;
- official effective-date notice;
- formal implementation document.

### Tier 1 — Official authorities and market institutions
Primary sources for policy purpose, reform content, implementation timetable, and official positions.

Priority institutions:
- Financial Services Commission (FSC Korea) — fsc.go.kr
- Financial Supervisory Service (FSS) — fss.or.kr
- Korea Exchange (KRX) — krx.co.kr
- Nextrade — nextrade.co.kr
- Korea Securities Depository (KSD) — ksd.or.kr
- Korea Financial Investment Association (KOFIA) — kofia.or.kr
- other Korean government/legal sources when directly authoritative

### Tier 2 — Official supporting material
Use for operational detail and post-implementation evidence.

Examples:
- official FAQ;
- official presentation;
- official statistics;
- official implementation review;
- official research/publication.

### Tier 3 — High-quality reporting
Examples: Reuters, Bloomberg, major Korean financial press.

Use only to:
- discover events;
- understand context or market reaction;
- identify the relevant official source.

Tier 3 alone is not sufficient to assert that a制度 has formally taken effect.

## Korean-language primary-text rule

For material institutional changes, search for and inspect the Korean official text when available.

Use English official pages for discovery and fast comprehension, but use the Korean original to confirm:
- exact dates;
- applicability;
- thresholds;
- exemptions;
- implementation mechanics;
- formal terminology.

Relevant recurring Korean terms include, but are not limited to:
- 공매도
- 대차거래
- 대체거래소
- 최선집행
- 알고리즘거래
- 상장폐지
- 기업공개
- 기업지배구조
- 기업가치 제고
- 자사주
- 외국인 투자
- 토큰증권
- 가상자산

## Evidence confidence

### High
Typical patterns:
- formal rule/statute + official notice;
- official Korean source with exact mechanics + corroborating official source;
- official statistics directly supporting an observable post-implementation fact.

### Medium
Typical patterns:
- one credible official source but ambiguity remains;
- credible media + partial official confirmation;
- official policy intention without finalized details.

### Low
Typical patterns:
- anonymous-source reporting;
- unofficial commentary;
- inferred effective date;
- secondary source with no primary support.

Only High-confidence claims should normally auto-edit the workbook.
