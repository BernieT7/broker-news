# Research Scope and Relevance Rules

## Core relevance question

Keep a development only if it directly affects one or more of:
- Korean securities/capital markets;
- securities firms/brokers;
- securities-investor trading behavior or protections;
- listed-company rules or shareholder rights;
- securities products;
- foreign participation in Korean securities markets;
- trading, clearing, settlement, custody, or market infrastructure;
- capital-market surveillance and enforcement.

The objective is **not** to track the entire Korean financial sector.

## In-scope examples

- KRX / Nextrade / ATS / alternative trading venues
- market structure, trading hours, fees, execution quality
- best execution / SOR
- short selling / securities lending / NSDS
- algorithmic trading / HFT / market abuse surveillance
- securities margin / CFD / leveraged securities products
- IPO / underwriting / listing / delisting
- private-market capital-market mechanisms
- corporate governance / Value-up / treasury shares / minority shareholders / dividends
- insider trading and securities disclosure rules
- foreign-investor market access / omnibus / English disclosure
- securities-account KYC / abnormal securities accounts
- ETF / ETN / derivatives / structured securities products
- STO / RWA / tokenized securities
- virtual-asset regulation when it materially intersects capital markets, securities firms, institutional participation, custody, market surveillance, or investment products
- settlement/custody/market infrastructure reforms

## Default exclusions

Exclude when the development is primarily about:
- insurance supervision;
- insurance products;
- K-ICS;
- IFRS 17 insurance implementation;
- insurance claims or pricing;
- bank lending;
- mortgages;
- credit cards;
- deposits;
- retail consumer lending;
- bank capital adequacy;
- ordinary consumer-finance policy unrelated to securities;
- financial-institution personnel changes;
- seminars, forums, awards, promotion campaigns;
- general macroeconomic commentary;
- ordinary KOSPI/KOSDAQ market moves;
- daily/weekly trading statistics with no institutional significance;
- isolated company events;
- isolated enforcement cases with no broader policy or regulatory implication.

## Cross-sector exception

Do not exclude solely because an announcement mentions banking or insurance.

Keep it if the **main capital-market effect** is material, for example:
- changing insurers' securities-investment limits;
- rules that materially change institutional capital flows into equities/bonds;
- bank/securities cross-sector rules that directly affect brokerage or market infrastructure.

Judge by **primary market impact**, not merely by industry label.

## Material institutional-event test

A candidate should normally involve at least one of:
- new regulatory framework;
- draft or formal proposal of material importance;
- statutory/regulatory amendment;
- formal approval;
- formal promulgation;
- formal effective date or launch;
- material change in supervisory method;
- material market-infrastructure change;
- material new securities-product framework;
- post-implementation evidence capable of changing an existing research conclusion.

## Exclude repeated descriptions

If a new page merely re-explains an institutional change already captured in the workbook, do not update merely because it has a newer publication date.

Ask:

> Does this source add a new fact, new stage, corrected fact, or material new outcome relative to the workbook?

If no, classify as no material update.
