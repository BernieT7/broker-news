# Fixed Search Matrix

## How to use this file

Every update run must cover all 22 topics.

For each topic perform:
1. **Policy-progress search** — proposal, draft, amendment, approval, promulgation, effect, launch, material rule change.
2. **Implementation-result search** — official statistics, policy review, adoption, market-quality evidence, compliance/enforcement results.

Search both English and Korean terms when useful. Prioritize official domains.

The terms below are discovery aids, **not sufficient relevance criteria**. A result still has to pass the five relevance gates in `scope.md`.

---

## 1. 交易市場效率與基礎設施

### 1-1 市場流動性與集中度
Discovery terms:
- liquidity / market concentration / market share / fragmented liquidity
- ATS / Nextrade / NXT / alternative trading system
- 유동성 / 시장집중 / 대체거래소

Keep when:
- market structure or venue competition changes liquidity concentration;
- official data materially changes the existing assessment.

Exclude:
- ordinary daily trading-volume reports with no structural implication.

### 1-2 交易時間與市場可用性
Discovery terms:
- trading hours / extended hours / pre-market / after-hours
- 거래시간 / 시간외 / 프리마켓 / 애프터마켓

Keep when:
- formal trading-session rules or access arrangements change;
- official evidence shows material usage/market-quality effects.

### 1-3 交易場所競爭、最佳執行與交易成本
Discovery terms:
- Nextrade / ATS / best execution / smart order routing / SOR
- trading fees / execution quality / venue competition
- 최선집행 / 주문집행 / 수수료 / 대체거래소

Exclude:
- temporary broker fee promotions unrelated to market rules.

### 1-4 交易系統韌性、容量與延遲
Discovery terms:
- system resilience / outage / market infrastructure / capacity / latency / matching engine
- 거래시스템 / 장애 / 지연 / 처리용량 / 시장인프라

Keep when:
- exchange/infrastructure-wide reform, formal resilience requirements, major capacity architecture or official systemic review changes.

Exclude:
- isolated minor IT incident without institutional response.

---

## 2. 市場公平與風險管理

### 2-1 價格發現與放空功能
Discovery terms:
- short selling / price discovery / short-sale ban / resumption
- 공매도 / 가격발견 / 공매도 재개

Keep when:
- rules governing whether/how short selling operates change;
- material official evidence changes the price-discovery/liquidity assessment.

### 2-2 異常交易、演算法與 HFT 監理
Discovery terms:
- algorithmic trading / HFT / high-frequency trading
- market abuse / abnormal trading / market surveillance
- 알고리즘거래 / 고빈도거래 / 이상거래 / 시장감시

Keep when:
- market-wide surveillance/enforcement framework changes;
- algorithmic/HFT obligations, controls, or sanctions create broader precedent.

Exclude:
- one isolated enforcement case with no broader institutional implication.

### 2-3 放空、借券與空頭透明度
Discovery terms:
- naked short selling / securities lending / short balance / short-position disclosure / NSDS
- 무차입공매도 / 대차거래 / 공매도 잔고 / 공매도 전산시스템

Keep when:
- position-management, borrowing confirmation, disclosure, monitoring, or data-integration rules change.

### 2-4 槓桿、信用與高風險交易風控
Discovery terms:
- margin trading / credit trading / leverage / leveraged product / CFD
- margin requirement / suitability for leveraged trading
- 신용거래 / 레버리지 / CFD / 증거금

Exclude:
- bank lending, mortgage, credit-card, or ordinary consumer-credit policy.

---

## 3. 上市品質與資本配置

### 3-1 殭屍證券與退場機制
Discovery terms:
- delisting / listing maintenance / zombie companies / penny stock / market-quality reform
- 상장폐지 / 상장유지 / 부실기업 / 좀비기업

Keep when:
- listing-maintenance thresholds, delisting timelines, review procedures, or market-wide exit rules change.

Exclude:
- ordinary delisting of a single company unless it establishes a material policy precedent.

### 3-2 IPO 定價、承銷與長期資金
Discovery terms:
- IPO / book building / preliminary book building / underwriting
- cornerstone investor / lock-up / offering allocation
- 기업공개 / 수요예측 / 주관사 / 코너스톤

Keep when:
- IPO pricing/allocation/underwriting framework changes or official evidence evaluates the reform.

Exclude:
- an individual IPO transaction.

### 3-3 未上市企業融資與資本市場深度
Discovery terms:
- private market / BDC / venture capital / growth capital / unlisted shares
- 비상장 / 기업성장집합투자기구 / BDC / 모험자본

Keep when:
- a capital-market vehicle/platform/regulatory channel for unlisted/growth companies changes.

Exclude:
- ordinary corporate financing news.

---

## 4. 公司治理與股東權益

### 4-1 公司治理與治理資訊揭露
Discovery terms:
- corporate governance / governance report / comply or explain / disclosure
- 기업지배구조 / 기업지배구조보고서 / 공시

Exclude:
- generic ESG events with no governance/disclosure-rule change.

### 4-2 少數股東保護、分拆上市與 M&A
Discovery terms:
- minority shareholders / spin-off / split listing / merger / M&A
- 물적분할 / 중복상장 / 소액주주 / 합병

Keep when:
- shareholder-protection, listing-review, merger/spin-off rights or duties change.

Exclude:
- one corporate M&A transaction.

### 4-3 企業價值、股東回報與庫藏股
Discovery terms:
- Corporate Value-up / value-up / treasury shares / buyback / cancellation / shareholder return
- 기업가치 제고 / 밸류업 / 자사주 / 소각 / 주주환원

Keep when:
- system-wide Value-up, treasury-share, cancellation, disclosure or shareholder-return rules change;
- official data materially evaluates adoption/effect.

Exclude:
- one company's voluntary buyback announcement.

### 4-4 內部人交易與資訊公平
Discovery terms:
- insider trading / insider transaction plan / pre-disclosure / MNPI
- 내부자거래 / 임원 주요주주 / 사전공시 / 미공개정보

Keep when:
- disclosure thresholds, timing, exemptions, sanctions, or system-wide monitoring changes.

Exclude:
- ordinary single-company insider transaction.

### 4-5 股利制度與股東權利
Discovery terms:
- dividend procedure / record date / shareholder rights / dividend disclosure
- 배당 / 배당기준일 / 주주권리

Keep when:
- dividend-setting procedure, record-date mechanics, or shareholder-right rules change.

Exclude:
- a single company's dividend decision.

---

## 5. 投資人參與與市場國際化

### 5-1 外資可近性、英文揭露與國際化
Discovery terms:
- foreign investor / foreign registration / IRC / omnibus account
- English disclosure / accessibility / global investor
- 외국인 투자 / 외국인등록 / 옴니버스 / 영문공시

Keep when:
- foreign-investor onboarding, account, reporting, FX/settlement access, or English-disclosure requirements change.

Exclude:
- ordinary foreign-investor net buying/selling statistics.

### 5-2 新投資人教育、適合度與主動風險提示
Discovery terms:
- suitability / appropriateness / investor education / risk warning
- leveraged investor qualification / learning requirement
- 적합성 / 적정성 / 투자자교육 / 위험고지

Keep when:
- formal suitability, qualification, education, warning, or broker-notification requirements change.

Exclude:
- general educational seminars or promotion campaigns.

### 5-3 帳戶治理、KYC、詐騙與異常帳戶
Discovery terms:
- securities account / KYC / CDD / abnormal account / dormant account / fraud account
- 증권계좌 / 고객확인 / CDD / 이상계좌 / 휴면계좌

Keep only when:
- directly tied to securities/brokerage accounts, capital-market intermediaries, or market-abuse/fraud controls relevant to securities.

Exclude by default:
- bank-account fraud policy with no securities-market linkage.

---

## 6. 金融創新與新市場發展

### 6-1 新商品創新與市場過熱管理
Discovery terms:
- ETF / ETN / derivatives / structured product / leveraged ETF / single-stock ETF
- exchange-traded product / product governance / overheating
- ETF / ETN / 파생상품 / 레버리지 / 상품규제

Keep when:
- product framework, eligibility, listing, distribution, suitability, or market-wide post-launch risk controls change.

Exclude:
- ordinary launch of one product unless it reflects a new institutional framework.

### 6-2 STO／RWA／證券數位化
Discovery terms:
- security token / tokenized securities / STO / RWA / DLT securities
- 토큰증권 / 증권형토큰 / 분산원장 / 실물자산토큰

Keep when:
- securities issuance, registration, distribution, custody, trading, settlement, or legal recognition changes.

Exclude:
- generic blockchain news unrelated to securities.

### 6-3 虛擬資產市場監理與法人參與
Discovery terms:
- virtual asset / crypto regulation / VASP / institutional crypto participation
- listing/delisting of virtual assets / custody / market abuse
- 가상자산 / 가상자산사업자 / 법인참여 / 상장 / 불공정거래

Keep when:
- market regulation, user-asset protection, institutional participation, custody, market surveillance, or securities-firm/capital-market linkage is material.

Exclude:
- token-price movements, ordinary exchange promotions, or generic crypto-market commentary.
