# Evidence Conflict Rules

## 1. Formal rule beats commentary

For exact legal/regulatory content:

formal rule / statute / market rule > official explanatory material > media reporting.

## 2. Finalized later information beats earlier plans

If an early official announcement says `planned`, and a later formal source confirms a different final rule/date, use the finalized information.

Preserve the policy lifecycle in column C when historically meaningful.

## 3. Korean primary text beats translated summary

If the Korean official text and English summary differ in detail, use the Korean primary text for the exact claim.

If the discrepancy cannot be resolved using a later or more formal source, do not auto-edit the disputed point.

## 4. Authority depends on the question

Do not use a simplistic agency ranking.

Typical authority mapping:
- policy purpose / government reform rationale → FSC;
- market/trading/listing implementation mechanics → KRX or Nextrade;
- supervisory/enforcement practice → FSS;
- settlement/custody mechanics → KSD;
- industry-level securities-firm data → KOFIA, when directly relevant.

## 5. Announcement date is not effective date

Distinguish:
- proposal date;
- announcement date;
- approval date;
- promulgation date;
- effective date;
- market launch date.

Never substitute an announcement date for an effective date.

## 6. Resolve definitions before resolving numbers

When two figures differ, first test whether the difference comes from:
- time period;
- denominator;
- trading value vs trading volume;
- KOSPI/KOSDAQ subset vs total market;
- regular session vs full day;
- accounts vs users;
- point-in-time vs average.

Use the statistic that matches the research statement and label its scope precisely.

## 7. Never average conflicting answers

If two comparable sources say 20% and 30%, never invent 25%.

Resolve the definition/source difference or flag for manual review.

## 8. Official policy changes are not source conflicts

If an agency originally planned January implementation and later delayed to July, this is a policy-development event.

Column C may preserve both stages when material.

## 9. Observable outcomes before causal claims

For implementation results, prefer statements such as:
- market share reached X%;
- spread moved by Y under stated methodology;
- N institutions adopted the system;
- enforcement cases changed by Z.

Do not convert correlation or media interpretation into a causal conclusion unless the evidence supports causality.

## 10. Unresolved high-quality conflict = no automatic edit

If conflicting high-quality sources remain unresolved:
- leave the disputed workbook content unchanged;
- list the item under `需人工確認`;
- identify the competing sources and the unresolved point.
