# Workbook Column Update Rules

## A — 六大分類

Automatic edit: **Never**.

This is the research taxonomy.

## B — 面向

Automatic add/delete/rename: **Never**.

New developments should first be mapped into the existing 22 topics.

If a material new theme truly does not fit, flag it for manual review rather than creating a row.

## C — 韓國近五年制度演進

Primary update field.

Purpose:
> What institutional change happened, and when?

Allowed updates:
- important proposal/draft;
- formal approval;
- amendment;
- promulgation;
- effective implementation;
- launch;
- material subsequent stage.

Drafts are allowed if material, but must be explicitly labelled using verbs such as:
- 提出;
- 預告;
- 草案;
- 規劃.

Never describe a proposal as implemented.

Style:
- chronological;
- concise;
- `年份：事件` or a precise date when materially useful;
- append or minimally consolidate;
- avoid rewriting unchanged historical entries.

## D — 韓國為什麼需要

Low-frequency update field.

Purpose:
> What problem, market failure, regulatory gap, or structural issue motivated the reform?

Edit only when new high-quality evidence materially changes or improves the understanding of the reform rationale.

Do not edit just because a new source phrases the same motivation differently.

## E — 制度實際改變了什麼

Purpose:
> What did the rules/market operation actually change, and what reliable post-implementation results are now observable?

This field contains two layers.

### Layer 1 — Institutional change
Describe concrete changes such as:
- trading time;
- eligibility threshold;
- market structure;
- broker obligation;
- disclosure requirement;
- supervisory mechanism;
- product scope;
- settlement/operational mechanism.

Think `before → after`.

### Layer 2 — Post-implementation evidence
Append only when reliable evidence exists, such as:
- official market share;
- adoption rate;
- trading activity;
- spread/liquidity/execution-quality metrics;
- official compliance/enforcement outcomes;
- formal policy review.

Prefer observable facts over evaluative adjectives.

Do not write `成效良好` unless the evidence supports a defined result. If no reliable outcome exists, keep only the institutional-change layer.

## F — 台灣現況／相同痛點

Default: **Do not edit**.

Auto-edit only when there is a clear new Taiwan official institutional fact or material market-structure change.

Do not force Taiwan to have the same problem as Korea.

## G — 對台股市場可能的影響

Default: **Do not automatically rewrite**.

If new Korean evidence clearly changes the impact mechanism, the skill may propose a revision. Because this is analytical, treat it as higher judgment risk.

When uncertain, keep the cell unchanged and flag for manual review.

## H — 台灣可借鏡方向／下一步研究

Highest judgment-risk core field.

Default: **Do not automatically rewrite**.

Only make a direct edit when new official evidence clearly invalidates or materially changes the existing research direction.

Otherwise flag a suggested review.

Preferred framing remains:
- 先比較…
- 量化…
- 評估…
- 盤點…
- 驗證…

Avoid jumping to `台灣應直接照做`.

## I — 韓國官方來源

Update when C/D/E changes.

Rules:
- prioritize direct supporting official pages/documents;
- one URL per line where practical;
- avoid duplicates;
- do not replace a precise source with a generic home page;
- retain older sources if they still support historical claims.

## J — 台灣官方來源

Update only when F/G/H materially changes due to new Taiwan evidence.

Use official Taiwan sources where possible.

## Existing-content correction rule

Existing text may be corrected only when new authoritative evidence shows:
- factual error;
- incorrect date;
- outdated preliminary detail superseded by final detail;
- materially incomplete institutional description.

**No stylistic-only edits.**

If facts are unchanged, preserve the original wording.
