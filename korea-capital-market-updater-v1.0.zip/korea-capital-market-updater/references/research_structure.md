# Research Workbook Structure

This skill is designed around the current workbook structure.

## Workbook purpose

The workbook is not merely a list of Korean policies. Its purpose is to use recent Korean capital-market reforms as a structured comparison framework for assessing:
- Taiwan's current market conditions;
- potential effects on Taiwan's securities market;
- implications for securities firms;
- topics that Taiwan should research, observe, or potentially learn from.

The workbook therefore connects:

**Why Korea changed → What Korea changed → What happened after implementation → Taiwan's comparable conditions → Potential Taiwan impact → Further research / lessons.**

## Expected sheets

### Sheet: 核心總表

Expected headers:

A. 六大分類
B. 面向
C. 韓國近五年制度演進
D. 韓國為什麼需要
E. 制度實際改變了什麼
F. 台灣現況／相同痛點
G. 對台股市場可能的影響
H. 台灣可借鏡方向／下一步研究
I. 韓國官方來源
J. 台灣官方來源

Note: E also contains reliable post-implementation evidence when available. Do not add a separate implementation-results column unless the user explicitly changes the workbook design.

### Sheet: 時間軸

Expected headers:

A. 生效時間
B. 正式生效／上線制度
C. 制度類型
D. 生效內容大綱
E. 韓國官方來源

## Six categories and 22 topics

### 1. 交易市場效率與基礎設施
- 1-1 市場流動性與集中度
- 1-2 交易時間與市場可用性
- 1-3 交易場所競爭、最佳執行與交易成本
- 1-4 交易系統韌性、容量與延遲

### 2. 市場公平與風險管理
- 2-1 價格發現與放空功能
- 2-2 異常交易、演算法與 HFT 監理
- 2-3 放空、借券與空頭透明度
- 2-4 槓桿、信用與高風險交易風控

### 3. 上市品質與資本配置
- 3-1 殭屍證券與退場機制
- 3-2 IPO 定價、承銷與長期資金
- 3-3 未上市企業融資與資本市場深度

### 4. 公司治理與股東權益
- 4-1 公司治理與治理資訊揭露
- 4-2 少數股東保護、分拆上市與 M&A
- 4-3 企業價值、股東回報與庫藏股
- 4-4 內部人交易與資訊公平
- 4-5 股利制度與股東權利

### 5. 投資人參與與市場國際化
- 5-1 外資可近性、英文揭露與國際化
- 5-2 新投資人教育、適合度與主動風險提示
- 5-3 帳戶治理、KYC、詐騙與異常帳戶

### 6. 金融創新與新市場發展
- 6-1 新商品創新與市場過熱管理
- 6-2 STO／RWA／證券數位化
- 6-3 虛擬資產市場監理與法人參與

## Structural constraints

- A/B are research taxonomy, not ordinary update fields.
- Do not add a new topic automatically.
- If an important new development does not fit any existing topic, flag it for manual review.
- Preserve the workbook's professional formatting and current sheet architecture.
