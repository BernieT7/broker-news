# Final QA Checklist

Do not finalize the updated workbook until this checklist has been completed.

## 1. Scope QA
- [ ] No irrelevant insurance-policy content was added.
- [ ] No irrelevant bank lending/mortgage/credit-card/deposit content was added.
- [ ] Each added item has a direct securities/capital-market connection.
- [ ] Generic financial news, seminars, promotions, personnel news, and ordinary market moves were excluded.

## 2. Coverage QA
- [ ] All 22 topics were checked.
- [ ] Each topic had both policy-progress and post-implementation searches where applicable.
- [ ] Search failures are explicitly noted.
- [ ] The as-of date is not advanced if coverage materially failed.

## 3. Evidence QA
- [ ] Each auto-edit has High evidence confidence.
- [ ] Important institutional changes use primary official evidence.
- [ ] Korean primary text was checked for material changes when available.
- [ ] Major effective dates / major statistics received a second confirmation where feasible.
- [ ] News was not used alone to assert formal effectiveness.
- [ ] Claim strength does not exceed evidence strength.

## 4. Conflict QA
- [ ] Announcement and effective dates are not confused.
- [ ] Conflicting figures were checked for denominator/time-period/scope differences.
- [ ] No conflicting numbers were averaged.
- [ ] Unresolved high-quality conflicts were left unchanged and flagged for manual review.

## 5. Content QA
- [ ] A/B taxonomy was not auto-edited.
- [ ] C records institutional evolution, not broad commentary.
- [ ] D explains reform need, not the rule itself.
- [ ] E clearly states the institutional change and only reliable implementation outcomes.
- [ ] Drafts/proposals were not written as implemented rules.
- [ ] Existing wording was preserved where facts did not change.
- [ ] No stylistic-only edits were made.

## 6. Taiwan QA
- [ ] F changed only with clear new Taiwan institutional evidence.
- [ ] G/H were not casually rewritten because Korea had a new announcement.
- [ ] Higher-judgment Taiwan implications are flagged for manual review where appropriate.
- [ ] J was updated only when Taiwan evidence changed.

## 7. Timeline QA
- [ ] Only formally effective/launched/applicable items were added.
- [ ] Timeline uses effective/launch date, not announcement date.
- [ ] Each new timeline entry has a direct Korean official source.

## 8. Rolling-window QA
- [ ] Five-year title/window was updated if the calendar year requires it.
- [ ] Important older institutional origin points were not mechanically deleted when still necessary for interpretation.

## 9. Abnormal-change QA
- [ ] Count materially modified topics.
- [ ] If >8 topics or ~30%+ of core table changed, show abnormal-change warning.
- [ ] Recommend priority spot checks for high-impact/high-risk modifications.

## 10. Workbook integrity QA
- [ ] Original workbook was not overwritten.
- [ ] Expected sheets remain present.
- [ ] Six categories remain present.
- [ ] 22 topics remain present unless the user explicitly changed the structure.
- [ ] No obvious #REF!, #VALUE!, #DIV/0!, #NAME?, #N/A errors.
- [ ] Existing merges/layout/formatting are substantially preserved.
- [ ] Source URLs remain legible and are not duplicated unnecessarily.
- [ ] The updated as-of date is correct.

## 11. Final response QA
- [ ] State update-through date.
- [ ] List auto-edits with reason + principal evidence.
- [ ] Separately list corrections of old information.
- [ ] List manual-review items.
- [ ] Recommend 2-4 priority spot checks when appropriate.
- [ ] Mention abnormal-change warning if triggered.
- [ ] Provide the new workbook, not the original file.
