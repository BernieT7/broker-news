---
name: korea-capital-market-updater
description: Update an uploaded Korean capital-market institutional research Excel workbook from its previous as-of date to the current date. Use when the user uploads the prior version of the Korea capital-market research workbook and asks to update it. Search high-quality Korean official sources for new securities-market regulations, drafts, implementation changes, and post-implementation evidence; exclude unrelated banking and insurance developments; conservatively edit only affected workbook fields; flag high-judgment items for human review; and return a validated updated Excel file without overwriting the original.
---

# Korea Capital Market Research Updater

## Mission

Update the user's existing Korea capital-market institutional research workbook **incrementally and conservatively**.

The workbook is the research output. This skill preserves the user's research framework and updates only facts and judgments that are materially changed by new evidence.

**Core principle: Update, do not rewrite.**

The skill should reduce repetitive research work while preserving human judgment for ambiguous or high-risk conclusions.

## Required input

The user should upload the previous version of the Excel workbook.

Expected structure is documented in `references/research_structure.md`.

If the workbook structure differs materially, map by header names first. If safe mapping is impossible, do not modify the workbook; explain the incompatibility.

## Standard invocation

Typical request:

> 使用韓國制度更新 Skill，把這份報告更新到今天。

Do not require the user to specify a start date if the workbook contains an explicit as-of date.

## Execution workflow

### 1. Read the workbook before searching

Inspect the entire workbook first.

Identify:
- sheet names;
- six categories;
- 22 research topics;
- current text in columns C-J;
- Korean and Taiwan sources;
- timeline entries;
- the current report as-of date;
- the current rolling five-year window.

Do **not** start external research until the workbook baseline is understood.

### 2. Determine the update window

Read all explicit as-of dates in the workbook, including the core table and timeline.

If the sheets use different as-of dates:
- keep the sheet-specific dates as separate baselines;
- use the **earliest** reliable as-of date to begin external event discovery, so no development is missed;
- when applying edits, avoid duplicating timeline events that were already covered by the timeline's later baseline.

Example:
- core table says `制度狀態截至 2026-08-11`;
- timeline says `資料截至 2026-08-18`;
- external discovery begins `2026-08-12`;
- core-table changes are evaluated from 2026-08-12 onward;
- timeline additions are evaluated against its existing entries and 2026-08-18 baseline.

After a fully successful update, synchronize the relevant workbook as-of notes to the current date unless the workbook intentionally distinguishes research-status date from timeline-data date.

The **event-discovery window is fixed**, but evidence may be traced backward to older primary documents when a new event cites an earlier proposal, rule, or legal basis.

If no reliable as-of date exists, ask the user for the previous update date. Never guess.

### 3. Perform complete coverage

Use `references/search_matrix.md`.

Every one of the 22 research topics must be checked before declaring the update complete.

For each topic, conduct both:

**A. Policy-progress search**
- proposal;
- draft;
- amendment;
- approval;
- promulgation;
- effective date;
- launch;
- material rule change.

**B. Post-implementation search**
- official statistics;
- official policy reviews;
- market adoption;
- trading volume/share;
- liquidity/spread/execution quality;
- compliance or enforcement outcomes;
- other evidence capable of changing the existing research conclusion.

Internally mark each topic as one of:
- `material_update_found`;
- `checked_no_material_update`;
- `needs_manual_review`;
- `search_failed`.

Never skip a topic simply because no obvious keyword comes to mind.

### 4. Apply the research-scope gates

Use `references/scope.md`.

A candidate must pass all five gates before it can modify the workbook:

1. **Newness** — Is this a new development within the discovery window?
2. **Scope** — Does it directly affect the Korean securities/capital market, brokers, securities investors, listed companies, securities products, foreign securities investment, or trading/settlement infrastructure?
3. **Materiality** — Is it a policy/regulatory event or a material post-implementation result?
4. **Incrementality** — Does it add information not already contained in the workbook?
5. **Evidence quality** — Is the evidence strong enough to support the exact claim?

If any gate fails, do not modify the workbook.

### 5. Build an Evidence Pack for every proposed edit

Before editing any cell, internally form:

- `claim`;
- `affected_topic`;
- `affected_columns`;
- `primary_evidence`;
- `supporting_evidence`;
- `evidence_confidence` = High / Medium / Low;
- `research_judgment_risk` = Low / Medium / High;
- `reason_for_change`;
- `timeline_eligible` = yes/no.

Use `references/source_rules.md` and `references/conflict_rules.md`.

### 6. Decide whether to auto-edit

Auto-edit only when:
- evidence confidence is **High**; and
- research judgment risk is **Low**, or the edit is a narrowly factual update with clear official support.

For **High evidence + Medium/High judgment risk**:
- update low-risk factual Korean fields if appropriate;
- do not automatically rewrite analytical Taiwan conclusions;
- flag the judgmental portion for manual review.

For **Medium confidence**:
- do not edit the disputed content;
- list it under `需人工確認`.

For **Low confidence**:
- exclude it from the workbook.

### 7. Apply workbook edits conservatively

Use `references/column_rules.md`.

Hard constraints:
- do not automatically change Category (A);
- do not automatically add/delete/rename Topic (B);
- no stylistic-only rewriting;
- preserve existing wording when facts have not changed;
- preserve workbook layout, formatting, merges, widths, and sheet structure as much as possible;
- never overwrite the user's original file.

### 8. Timeline rules

Add a timeline entry only for:
- formal effectiveness;
- formal market launch;
- formal start of applicability.

Do not add:
- proposal;
- draft;
- approved-but-not-effective;
- announced-but-not-effective items.

Use the actual effective/launch date, not the announcement date.

### 9. Rolling five-year window

The report uses a rolling five-year research window.

Example:
- 2026: 2022-2026;
- 2027: 2023-2027.

Do not mechanically delete older information that remains necessary to understand the current institutional structure. Compress important historical origin points into concise background when necessary.

### 10. Abnormal-change safeguard

After preparing edits, calculate change breadth.

Trigger an **abnormal-change warning** if either:
- more than 8 of the 22 topics are materially modified; or
- more than approximately 30% of the core table is materially changed.

When triggered:
- still finish research and prepare the updated workbook if edits are high-confidence;
- prominently warn the user that the breadth of changes is unusual;
- prioritize manual spot checks before relying on the workbook.

### 11. Quality assurance

Run the checklist in `references/qa_checklist.md` after edits.

Also run `scripts/validate_workbook.py` when feasible.

Do not update the workbook as-of date if the research/search process materially failed or coverage is incomplete.

If all 22 topics were checked successfully and there are no material edits, it is valid to update the report as-of date and state that no material changes were found.

### 12. Output

Save a **new** workbook:

`韓國近五年制度研究_更新至YYYY-MM-DD.xlsx`

Do not overwrite the uploaded workbook.

## Final response format

Keep the response concise.

Use this structure:

**已更新至 YYYY/MM/DD**

**已自動更新 N 項**
- `[topic code + topic name]` — reason for change; principal evidence source.

**修正既有資訊 N 項**
- only list factual corrections or material clarifications.

**需人工確認 N 項**
- explain why automatic editing was withheld.

**建議優先抽查**
- list 2-4 highest-risk or highest-impact modifications, if any.

If abnormal-change safeguard triggered, state it clearly.

Then provide the updated workbook link.

Do not produce an Update Log worksheet unless the user explicitly requests one.

## Non-negotiable quality principles

1. **Primary source first.**
2. **Full coverage before completion.**
3. **Compare before update.**
4. **Claim strength must not exceed evidence strength.**
5. **Update, do not rewrite.**
6. **When uncertain, do not edit.**
