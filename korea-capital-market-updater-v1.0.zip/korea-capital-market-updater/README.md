# Korea Capital Market Research Updater

A reusable Skill for updating the existing Korean capital-market institutional research workbook.

## Purpose

The Excel workbook stores the research result and comparison framework.

This Skill stores the **update methodology**:
- what to search;
- what to exclude;
- which sources are authoritative;
- how to resolve conflicts;
- when each workbook field may change;
- when human review is required;
- how to validate the final workbook.

## Intended user flow

1. Install/copy this Skill.
2. Upload the previous Excel workbook.
3. Ask: `使用韓國制度更新 Skill，把這份報告更新到今天。`
4. Receive:
   - a new updated workbook;
   - a concise change summary;
   - manual-review items;
   - priority spot-check recommendations.

## Design philosophy

- High-quality, conservative, semi-autonomous updater.
- Update, not rewrite.
- High-confidence facts can be automated.
- High-judgment conclusions remain human-reviewed.
- Uncertainty does not enter the formal workbook automatically.

## Skill contents

- `SKILL.md` — execution workflow
- `references/research_structure.md` — workbook purpose/structure
- `references/scope.md` — relevance and exclusion rules
- `references/search_matrix.md` — fixed 22-topic coverage
- `references/source_rules.md` — source hierarchy and confidence
- `references/conflict_rules.md` — conflict resolution
- `references/column_rules.md` — C-J update rules
- `references/qa_checklist.md` — final QA
- `scripts/validate_workbook.py` — lightweight deterministic workbook validator

## Validator

Run:

```bash
python scripts/validate_workbook.py /path/to/workbook.xlsx
```

The validator checks the expected sheets, headers, 22 topics, obvious formula-error strings, source URL syntax, and as-of date presence.

It does not replace substantive research QA.
