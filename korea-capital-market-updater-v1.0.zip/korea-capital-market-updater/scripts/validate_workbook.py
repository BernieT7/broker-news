#!/usr/bin/env python3
"""Lightweight structural validator for the Korea capital-market research workbook.

Uses only the Python standard library so the skill has no external Python dependency.
It validates workbook structure, expected headers/topics, basic error strings, URLs,
and attempts to identify the report as-of date.

Usage:
    python scripts/validate_workbook.py /path/to/workbook.xlsx

Exit code:
    0 = core structural checks passed
    1 = validation problems found
    2 = file/read error
"""

from __future__ import annotations

import re
import sys
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urlparse

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "rel": "http://schemas.openxmlformats.org/package/2006/relationships"}

EXPECTED_TOPICS = [
    "1-1 市場流動性與集中度",
    "1-2 交易時間與市場可用性",
    "1-3 交易場所競爭、最佳執行與交易成本",
    "1-4 交易系統韌性、容量與延遲",
    "2-1 價格發現與放空功能",
    "2-2 異常交易、演算法與 HFT 監理",
    "2-3 放空、借券與空頭透明度",
    "2-4 槓桿、信用與高風險交易風控",
    "3-1 殭屍證券與退場機制",
    "3-2 IPO 定價、承銷與長期資金",
    "3-3 未上市企業融資與資本市場深度",
    "4-1 公司治理與治理資訊揭露",
    "4-2 少數股東保護、分拆上市與 M&A",
    "4-3 企業價值、股東回報與庫藏股",
    "4-4 內部人交易與資訊公平",
    "4-5 股利制度與股東權利",
    "5-1 外資可近性、英文揭露與國際化",
    "5-2 新投資人教育、適合度與主動風險提示",
    "5-3 帳戶治理、KYC、詐騙與異常帳戶",
    "6-1 新商品創新與市場過熱管理",
    "6-2 STO／RWA／證券數位化",
    "6-3 虛擬資產市場監理與法人參與",
]

EXPECTED_CORE_HEADERS = [
    "六大分類", "面向", "韓國近五年制度演進", "韓國為什麼需要",
    "制度實際改變了什麼", "台灣現況／相同痛點", "對台股市場可能的影響",
    "台灣可借鏡方向／下一步研究", "韓國官方來源", "台灣官方來源",
]

EXPECTED_TIMELINE_HEADERS = [
    "生效時間", "正式生效／上線制度", "制度類型", "生效內容大綱", "韓國官方來源"
]

ERROR_TOKENS = ("#REF!", "#VALUE!", "#DIV/0!", "#NAME?", "#N/A")
URL_RE = re.compile(r"https?://[^\s]+")
DATE_RE = re.compile(r"(?:制度狀態截至|資料截至)\s*(\d{4}[-/.]\d{1,2}[-/.]\d{1,2})")


def col_letter(cell_ref: str) -> str:
    m = re.match(r"([A-Z]+)", cell_ref)
    return m.group(1) if m else ""


def load_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    out = []
    for si in root.findall("m:si", NS):
        parts = []
        for t in si.iterfind(".//m:t", NS):
            parts.append(t.text or "")
        out.append("".join(parts))
    return out


def workbook_sheet_paths(zf: zipfile.ZipFile) -> dict[str, str]:
    wb = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    relmap = {r.attrib["Id"]: r.attrib["Target"] for r in rels.findall("rel:Relationship", NS)}
    result = {}
    for s in wb.find("m:sheets", NS):
        name = s.attrib["name"]
        rid = s.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
        target = relmap[rid]
        if not target.startswith("/"):
            target = "xl/" + target.lstrip("./")
        else:
            target = target.lstrip("/")
        result[name] = target
    return result


def read_sheet(zf: zipfile.ZipFile, path: str, shared: list[str]) -> dict[str, str]:
    root = ET.fromstring(zf.read(path))
    cells = {}
    for c in root.findall(".//m:c", NS):
        ref = c.attrib.get("r", "")
        typ = c.attrib.get("t")
        value = ""
        if typ == "inlineStr":
            value = "".join((t.text or "") for t in c.iterfind(".//m:t", NS))
        else:
            v = c.find("m:v", NS)
            if v is not None and v.text is not None:
                if typ == "s":
                    try:
                        value = shared[int(v.text)]
                    except (ValueError, IndexError):
                        value = v.text
                else:
                    value = v.text
            f = c.find("m:f", NS)
            if f is not None and not value:
                value = "=" + (f.text or "")
        cells[ref] = value
    return cells


def row_values(cells: dict[str, str], row: int, cols: str) -> list[str]:
    return [cells.get(f"{c}{row}", "") for c in cols]


def contains_header(actual: str, expected: str) -> bool:
    # The C header may include a rolling-year suffix, so prefix/normalized matching is intentional.
    a = actual.replace("（", "(").replace("）", ")").strip()
    e = expected.replace("（", "(").replace("）", ")").strip()
    return a == e or a.startswith(e)


def validate(path: Path) -> tuple[list[str], list[str]]:
    errors, warnings = [], []
    with zipfile.ZipFile(path) as zf:
        shared = load_shared_strings(zf)
        sheet_paths = workbook_sheet_paths(zf)

        for name in ("核心總表", "時間軸"):
            if name not in sheet_paths:
                errors.append(f"Missing required sheet: {name}")
        if errors:
            return errors, warnings

        core = read_sheet(zf, sheet_paths["核心總表"], shared)
        timeline = read_sheet(zf, sheet_paths["時間軸"], shared)

        core_headers = row_values(core, 3, "ABCDEFGHIJ")
        for actual, expected in zip(core_headers, EXPECTED_CORE_HEADERS):
            if not contains_header(actual, expected):
                errors.append(f"Core header mismatch: expected '{expected}', got '{actual}'")

        timeline_headers = row_values(timeline, 4, "ABCDE")
        for actual, expected in zip(timeline_headers, EXPECTED_TIMELINE_HEADERS):
            if not contains_header(actual, expected):
                errors.append(f"Timeline header mismatch: expected '{expected}', got '{actual}'")

        actual_topics = [core.get(f"B{r}", "").strip() for r in range(4, 26) if core.get(f"B{r}", "").strip()]
        missing = [t for t in EXPECTED_TOPICS if t not in actual_topics]
        unexpected = [t for t in actual_topics if t not in EXPECTED_TOPICS]
        if missing:
            errors.append("Missing expected topics: " + "; ".join(missing))
        if unexpected:
            warnings.append("Unexpected topics present: " + "; ".join(unexpected))
        if len(actual_topics) != 22:
            errors.append(f"Expected 22 topics, found {len(actual_topics)}")

        all_values = list(core.values()) + list(timeline.values())
        for token in ERROR_TOKENS:
            if any(token in v for v in all_values if isinstance(v, str)):
                errors.append(f"Workbook contains error token: {token}")

        # Basic URL syntax check on source columns.
        source_cells = []
        for r in range(4, 26):
            source_cells.extend([core.get(f"I{r}", ""), core.get(f"J{r}", "")])
        for r in range(5, 200):
            if f"E{r}" not in timeline:
                continue
            source_cells.append(timeline.get(f"E{r}", ""))
        for text in source_cells:
            for url in URL_RE.findall(text or ""):
                p = urlparse(url.rstrip(".,;)"))
                if p.scheme not in ("http", "https") or not p.netloc:
                    warnings.append(f"Suspicious URL: {url}")

        asof_candidates = []
        for ref in ("A2", "A1"):
            for cells in (core, timeline):
                m = DATE_RE.search(cells.get(ref, ""))
                if m:
                    asof_candidates.append(m.group(1))
        if not asof_candidates:
            warnings.append("No explicit as-of date found in expected title/note cells.")
        else:
            warnings.append("Detected as-of date(s): " + ", ".join(sorted(set(asof_candidates))))

    return errors, warnings


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate_workbook.py <workbook.xlsx>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        print(f"File not found: {path}", file=sys.stderr)
        return 2
    try:
        errors, warnings = validate(path)
    except Exception as exc:
        print(f"Validation failed to read workbook: {exc}", file=sys.stderr)
        return 2

    print("Workbook validation")
    print(f"File: {path}")
    for w in warnings:
        print(f"WARNING: {w}")
    if errors:
        for e in errors:
            print(f"ERROR: {e}")
        print(f"RESULT: FAIL ({len(errors)} error(s))")
        return 1
    print("RESULT: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
